package com.example.tubes_makanapahariini;

public interface FragmentListener {
    void changePage(int page);
    void closeApplication();
    void showMessage(String result);
    //YOU CAN ADD MORE INTERFACES IF THERE ANY IMPORTANCE
}
